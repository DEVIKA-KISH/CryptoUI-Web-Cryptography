#!/usr/bin/env python3
"""
CryptoUI Pro - Python Library Installer
========================================

This script installs all required cryptography libraries for the
CryptoUI Pro Python toolkit.

Run with: python install_crypto.py
"""

import subprocess
import sys

# Library groups
CORE_LIBS = [
    ("cryptography", "Main crypto library (AES, RSA, hashing)"),
    ("pycryptodome", "Additional ciphers and algorithms"),
]

PQC_LIBS = [
    ("kyber-py", "Pure Python Kyber (ML-KEM) implementation"),
    ("dilithium-py", "Pure Python Dilithium (ML-DSA) implementation"),
]

PQC_ALTERNATIVE = [
    ("pqcrypto", "Fast PQC with C bindings (Kyber, Dilithium)"),
    ("pqcryptography", "Easy PQC wrapper (liboqs-based)"),
]

OPTIONAL_LIBS = [
    ("argon2-cffi", "Argon2 password hashing"),
    ("PyNaCl", "Python bindings for libsodium"),
    ("bcrypt", "BCrypt password hashing"),
]


def install_package(package_name: str, description: str) -> bool:
    """Install a Python package using pip."""
    print(f"\n📦 Installing {package_name}...")
    print(f"   {description}")
    
    try:
        subprocess.check_call([
            sys.executable, "-m", "pip", "install", 
            package_name, "--quiet", "--break-system-packages"
        ])
        print(f"   ✅ {package_name} installed successfully!")
        return True
    except subprocess.CalledProcessError:
        print(f"   ⚠️ Failed to install {package_name}")
        return False


def check_package(package_name: str) -> bool:
    """Check if a package is already installed."""
    try:
        # Handle package names that differ from import names
        import_name = package_name.replace("-", "_").lower()
        if package_name == "pycryptodome":
            import_name = "Crypto"
        elif package_name == "PyNaCl":
            import_name = "nacl"
        elif package_name == "argon2-cffi":
            import_name = "argon2"
        elif package_name == "kyber-py":
            import_name = "kyber_py"
        elif package_name == "dilithium-py":
            import_name = "dilithium_py"
        
        __import__(import_name)
        return True
    except ImportError:
        return False


def main():
    print("=" * 60)
    print("🔐 CryptoUI Pro - Python Library Installer")
    print("=" * 60)
    
    print("\nThis script will install cryptography libraries for:")
    print("  • Modern encryption (AES-256, ChaCha20, RSA)")
    print("  • Post-quantum cryptography (Kyber, Dilithium)")
    print("  • Hashing (SHA-256/512, HMAC, PBKDF2, Argon2)")
    print("  • Classical ciphers (built into toolkit)")
    
    # Check existing installations
    print("\n📋 Checking existing installations...")
    
    all_libs = CORE_LIBS + PQC_LIBS
    installed = []
    not_installed = []
    
    for pkg, desc in all_libs:
        if check_package(pkg):
            installed.append(pkg)
            print(f"   ✅ {pkg} - already installed")
        else:
            not_installed.append((pkg, desc))
            print(f"   ❌ {pkg} - not installed")
    
    if not not_installed:
        print("\n🎉 All required libraries are already installed!")
    else:
        print(f"\n📥 {len(not_installed)} libraries need to be installed.")
        
        response = input("\nProceed with installation? [Y/n]: ").strip().lower()
        if response in ('', 'y', 'yes'):
            print("\n" + "-" * 60)
            print("Installing libraries...")
            print("-" * 60)
            
            success_count = 0
            fail_count = 0
            
            for pkg, desc in not_installed:
                if install_package(pkg, desc):
                    success_count += 1
                else:
                    fail_count += 1
            
            print("\n" + "-" * 60)
            print(f"Installation complete: {success_count} succeeded, {fail_count} failed")
            print("-" * 60)
    
    # Ask about optional libraries
    print("\n" + "=" * 60)
    print("📦 Optional Libraries")
    print("=" * 60)
    print("\nThe following optional libraries provide additional features:")
    
    for pkg, desc in OPTIONAL_LIBS:
        status = "✅" if check_package(pkg) else "❌"
        print(f"   {status} {pkg} - {desc}")
    
    for pkg, desc in PQC_ALTERNATIVE:
        status = "✅" if check_package(pkg) else "❌"
        print(f"   {status} {pkg} - {desc}")
    
    response = input("\nInstall optional libraries? [y/N]: ").strip().lower()
    if response in ('y', 'yes'):
        for pkg, desc in OPTIONAL_LIBS + PQC_ALTERNATIVE:
            if not check_package(pkg):
                install_package(pkg, desc)
    
    # Final summary
    print("\n" + "=" * 60)
    print("🎉 Setup Complete!")
    print("=" * 60)
    print("\nUsage:")
    print("  1. Import the toolkit:")
    print("     from crypto_toolkit import *")
    print("\n  2. Run the demo:")
    print("     python crypto_toolkit.py")
    print("\n  3. Example - AES encryption:")
    print("     encrypted = AES256GCM.encrypt('Hello', 'my-secret-key')")
    print("     decrypted = AES256GCM.decrypt(encrypted, 'my-secret-key')")
    print("\n  4. Example - SHA-256 hashing:")
    print("     hash = Hashing.sha256('Hello')")
    print("\n" + "=" * 60)


if __name__ == "__main__":
    main()
