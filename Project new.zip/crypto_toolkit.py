#!/usr/bin/env python3
"""
CryptoUI Pro - Python Cryptography Toolkit
==========================================

A comprehensive Python library for encryption, hashing, and encoding.
Mirrors the functionality of the CryptoUI Pro web application.

Features:
- Modern Symmetric: AES-256-GCM, ChaCha20-Poly1305
- Asymmetric: RSA-OAEP (2048-bit)
- Post-Quantum: Kyber-768, Dilithium-3
- Hashing: SHA-256, SHA-512, HMAC-SHA256, PBKDF2
- Classical: Caesar, Vigenère, ROT13, Atbash
- Encoding: Base64, Hex, Binary, URL

Author: CryptoUI Pro
License: MIT
"""

import os
import base64
import hashlib
import hmac
import binascii
import urllib.parse
from typing import Tuple, Optional, Union
import json

# ============================================================
# MODERN SYMMETRIC ENCRYPTION
# ============================================================

class AES256GCM:
    """AES-256-GCM encryption using the cryptography library."""
    
    @staticmethod
    def encrypt(plaintext: str, key: str) -> dict:
        """
        Encrypt plaintext with AES-256-GCM.
        
        Args:
            plaintext: Text to encrypt
            key: Encryption key (will be padded/truncated to 32 bytes)
            
        Returns:
            dict with 'iv', 'ciphertext', 'tag' (all base64 encoded)
        """
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        
        # Ensure key is 32 bytes (256 bits)
        key_bytes = key.encode('utf-8')[:32].ljust(32, b'\0')
        
        # Generate random IV (12 bytes for GCM)
        iv = os.urandom(12)
        
        # Encrypt
        aesgcm = AESGCM(key_bytes)
        ciphertext = aesgcm.encrypt(iv, plaintext.encode('utf-8'), None)
        
        return {
            'algorithm': 'AES-256-GCM',
            'iv': base64.b64encode(iv).decode('utf-8'),
            'ciphertext': base64.b64encode(ciphertext).decode('utf-8')
        }
    
    @staticmethod
    def decrypt(encrypted_data: dict, key: str) -> str:
        """
        Decrypt AES-256-GCM encrypted data.
        
        Args:
            encrypted_data: dict with 'iv' and 'ciphertext'
            key: Decryption key
            
        Returns:
            Decrypted plaintext
        """
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        
        key_bytes = key.encode('utf-8')[:32].ljust(32, b'\0')
        iv = base64.b64decode(encrypted_data['iv'])
        ciphertext = base64.b64decode(encrypted_data['ciphertext'])
        
        aesgcm = AESGCM(key_bytes)
        plaintext = aesgcm.decrypt(iv, ciphertext, None)
        
        return plaintext.decode('utf-8')


class ChaCha20Poly1305:
    """ChaCha20-Poly1305 encryption."""
    
    @staticmethod
    def encrypt(plaintext: str, key: str) -> dict:
        """Encrypt with ChaCha20-Poly1305."""
        from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305 as CC20P1305
        
        key_bytes = key.encode('utf-8')[:32].ljust(32, b'\0')
        nonce = os.urandom(12)
        
        chacha = CC20P1305(key_bytes)
        ciphertext = chacha.encrypt(nonce, plaintext.encode('utf-8'), None)
        
        return {
            'algorithm': 'ChaCha20-Poly1305',
            'nonce': base64.b64encode(nonce).decode('utf-8'),
            'ciphertext': base64.b64encode(ciphertext).decode('utf-8')
        }
    
    @staticmethod
    def decrypt(encrypted_data: dict, key: str) -> str:
        """Decrypt ChaCha20-Poly1305 encrypted data."""
        from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305 as CC20P1305
        
        key_bytes = key.encode('utf-8')[:32].ljust(32, b'\0')
        nonce = base64.b64decode(encrypted_data['nonce'])
        ciphertext = base64.b64decode(encrypted_data['ciphertext'])
        
        chacha = CC20P1305(key_bytes)
        plaintext = chacha.decrypt(nonce, ciphertext, None)
        
        return plaintext.decode('utf-8')


# ============================================================
# ASYMMETRIC ENCRYPTION (RSA)
# ============================================================

class RSA_OAEP:
    """RSA-OAEP encryption (2048-bit)."""
    
    @staticmethod
    def generate_keypair() -> Tuple[bytes, bytes]:
        """
        Generate RSA-2048 key pair.
        
        Returns:
            Tuple of (public_key_pem, private_key_pem)
        """
        from cryptography.hazmat.primitives.asymmetric import rsa
        from cryptography.hazmat.primitives import serialization
        
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048
        )
        
        public_key = private_key.public_key()
        
        private_pem = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption()
        )
        
        public_pem = public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )
        
        return public_pem, private_pem
    
    @staticmethod
    def encrypt(plaintext: str, public_key_pem: bytes) -> dict:
        """Encrypt with RSA-OAEP."""
        from cryptography.hazmat.primitives import serialization, hashes
        from cryptography.hazmat.primitives.asymmetric import padding
        
        public_key = serialization.load_pem_public_key(public_key_pem)
        
        ciphertext = public_key.encrypt(
            plaintext.encode('utf-8'),
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        )
        
        return {
            'algorithm': 'RSA-OAEP-2048',
            'ciphertext': base64.b64encode(ciphertext).decode('utf-8')
        }
    
    @staticmethod
    def decrypt(encrypted_data: dict, private_key_pem: bytes) -> str:
        """Decrypt RSA-OAEP encrypted data."""
        from cryptography.hazmat.primitives import serialization, hashes
        from cryptography.hazmat.primitives.asymmetric import padding
        
        private_key = serialization.load_pem_private_key(private_key_pem, password=None)
        ciphertext = base64.b64decode(encrypted_data['ciphertext'])
        
        plaintext = private_key.decrypt(
            ciphertext,
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        )
        
        return plaintext.decode('utf-8')


# ============================================================
# POST-QUANTUM CRYPTOGRAPHY
# ============================================================

class Kyber768:
    """
    Kyber-768 Post-Quantum Key Encapsulation Mechanism.
    
    Requires: pip install kyber-py
    Or: pip install pqcrypto
    """
    
    @staticmethod
    def generate_keypair():
        """Generate Kyber-768 key pair."""
        try:
            from kyber_py.ml_kem import ML_KEM_768
            public_key, private_key = ML_KEM_768.keygen()
            return public_key, private_key
        except ImportError:
            try:
                from pqcrypto.kem.kyber768 import generate_keypair
                return generate_keypair()
            except ImportError:
                raise ImportError(
                    "Install kyber-py or pqcrypto: pip install kyber-py pqcrypto"
                )
    
    @staticmethod
    def encapsulate(public_key) -> Tuple[bytes, bytes]:
        """
        Encapsulate to generate shared secret and ciphertext.
        
        Returns:
            Tuple of (shared_secret, ciphertext)
        """
        try:
            from kyber_py.ml_kem import ML_KEM_768
            shared_secret, ciphertext = ML_KEM_768.encaps(public_key)
            return shared_secret, ciphertext
        except ImportError:
            try:
                from pqcrypto.kem.kyber768 import encapsulate
                ciphertext, shared_secret = encapsulate(public_key)
                return shared_secret, ciphertext
            except ImportError:
                raise ImportError("Install kyber-py or pqcrypto")
    
    @staticmethod
    def decapsulate(ciphertext, private_key) -> bytes:
        """Decapsulate to recover shared secret."""
        try:
            from kyber_py.ml_kem import ML_KEM_768
            shared_secret = ML_KEM_768.decaps(private_key, ciphertext)
            return shared_secret
        except ImportError:
            try:
                from pqcrypto.kem.kyber768 import decapsulate
                return decapsulate(ciphertext, private_key)
            except ImportError:
                raise ImportError("Install kyber-py or pqcrypto")


class Dilithium3:
    """
    Dilithium-3 Post-Quantum Digital Signature Algorithm.
    
    Requires: pip install dilithium-py
    Or: pip install pqcrypto
    """
    
    @staticmethod
    def generate_keypair():
        """Generate Dilithium-3 key pair."""
        try:
            from dilithium_py.ml_dsa import ML_DSA_65
            public_key, private_key = ML_DSA_65.keygen()
            return public_key, private_key
        except ImportError:
            try:
                from pqcrypto.sign.dilithium3 import generate_keypair
                return generate_keypair()
            except ImportError:
                raise ImportError(
                    "Install dilithium-py or pqcrypto: pip install dilithium-py pqcrypto"
                )
    
    @staticmethod
    def sign(message: bytes, private_key) -> bytes:
        """Sign a message with Dilithium-3."""
        try:
            from dilithium_py.ml_dsa import ML_DSA_65
            signature = ML_DSA_65.sign(private_key, message)
            return signature
        except ImportError:
            try:
                from pqcrypto.sign.dilithium3 import sign
                return sign(private_key, message)
            except ImportError:
                raise ImportError("Install dilithium-py or pqcrypto")
    
    @staticmethod
    def verify(message: bytes, signature: bytes, public_key) -> bool:
        """Verify a Dilithium-3 signature."""
        try:
            from dilithium_py.ml_dsa import ML_DSA_65
            return ML_DSA_65.verify(public_key, message, signature)
        except ImportError:
            try:
                from pqcrypto.sign.dilithium3 import verify
                verify(public_key, message, signature)
                return True
            except:
                return False


# ============================================================
# HASHING FUNCTIONS
# ============================================================

class Hashing:
    """Common hashing functions."""
    
    @staticmethod
    def sha256(data: str) -> str:
        """Generate SHA-256 hash."""
        return hashlib.sha256(data.encode('utf-8')).hexdigest()
    
    @staticmethod
    def sha512(data: str) -> str:
        """Generate SHA-512 hash."""
        return hashlib.sha512(data.encode('utf-8')).hexdigest()
    
    @staticmethod
    def md5(data: str) -> str:
        """Generate MD5 hash (not for security!)."""
        return hashlib.md5(data.encode('utf-8')).hexdigest()
    
    @staticmethod
    def sha3_256(data: str) -> str:
        """Generate SHA3-256 hash."""
        return hashlib.sha3_256(data.encode('utf-8')).hexdigest()
    
    @staticmethod
    def sha3_512(data: str) -> str:
        """Generate SHA3-512 hash."""
        return hashlib.sha3_512(data.encode('utf-8')).hexdigest()
    
    @staticmethod
    def blake2b(data: str) -> str:
        """Generate BLAKE2b hash."""
        return hashlib.blake2b(data.encode('utf-8')).hexdigest()
    
    @staticmethod
    def blake2s(data: str) -> str:
        """Generate BLAKE2s hash."""
        return hashlib.blake2s(data.encode('utf-8')).hexdigest()


class HMAC_SHA256:
    """HMAC-SHA256 message authentication."""
    
    @staticmethod
    def generate(message: str, key: str) -> str:
        """Generate HMAC-SHA256."""
        return hmac.new(
            key.encode('utf-8'),
            message.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()
    
    @staticmethod
    def verify(message: str, key: str, expected_hmac: str) -> bool:
        """Verify HMAC-SHA256."""
        computed = HMAC_SHA256.generate(message, key)
        return hmac.compare_digest(computed, expected_hmac)


class PBKDF2:
    """Password-Based Key Derivation Function 2."""
    
    @staticmethod
    def derive(password: str, salt: str = None, iterations: int = 100000, 
               key_length: int = 32) -> Tuple[str, str]:
        """
        Derive key from password using PBKDF2-SHA256.
        
        Args:
            password: Password to derive key from
            salt: Salt (will be generated if not provided)
            iterations: Number of iterations (default 100,000)
            key_length: Length of derived key in bytes
            
        Returns:
            Tuple of (derived_key_hex, salt_hex)
        """
        if salt is None:
            salt = os.urandom(16)
        else:
            salt = salt.encode('utf-8') if isinstance(salt, str) else salt
        
        derived_key = hashlib.pbkdf2_hmac(
            'sha256',
            password.encode('utf-8'),
            salt,
            iterations,
            dklen=key_length
        )
        
        return derived_key.hex(), salt.hex() if isinstance(salt, bytes) else salt


# ============================================================
# CLASSICAL CIPHERS (Educational)
# ============================================================

class CaesarCipher:
    """Caesar cipher - ancient substitution cipher."""
    
    @staticmethod
    def encrypt(plaintext: str, shift: int = 3) -> str:
        """Encrypt with Caesar cipher."""
        result = []
        for char in plaintext:
            if char.isalpha():
                base = ord('A') if char.isupper() else ord('a')
                result.append(chr((ord(char) - base + shift) % 26 + base))
            else:
                result.append(char)
        return ''.join(result)
    
    @staticmethod
    def decrypt(ciphertext: str, shift: int = 3) -> str:
        """Decrypt Caesar cipher."""
        return CaesarCipher.encrypt(ciphertext, -shift)
    
    @staticmethod
    def brute_force(ciphertext: str) -> list:
        """Try all possible shifts (1-25)."""
        return [(i, CaesarCipher.decrypt(ciphertext, i)) for i in range(1, 26)]


class VigenereCipher:
    """Vigenère cipher - polyalphabetic substitution."""
    
    @staticmethod
    def encrypt(plaintext: str, key: str) -> str:
        """Encrypt with Vigenère cipher."""
        key = key.upper()
        result = []
        key_index = 0
        
        for char in plaintext:
            if char.isalpha():
                base = ord('A') if char.isupper() else ord('a')
                shift = ord(key[key_index % len(key)]) - ord('A')
                result.append(chr((ord(char) - base + shift) % 26 + base))
                key_index += 1
            else:
                result.append(char)
        
        return ''.join(result)
    
    @staticmethod
    def decrypt(ciphertext: str, key: str) -> str:
        """Decrypt Vigenère cipher."""
        key = key.upper()
        result = []
        key_index = 0
        
        for char in ciphertext:
            if char.isalpha():
                base = ord('A') if char.isupper() else ord('a')
                shift = ord(key[key_index % len(key)]) - ord('A')
                result.append(chr((ord(char) - base - shift + 26) % 26 + base))
                key_index += 1
            else:
                result.append(char)
        
        return ''.join(result)


class ROT13:
    """ROT13 - simple letter substitution (shift by 13)."""
    
    @staticmethod
    def transform(text: str) -> str:
        """Apply ROT13 transformation (encrypt = decrypt)."""
        return CaesarCipher.encrypt(text, 13)


class AtbashCipher:
    """Atbash cipher - Hebrew mirror cipher (A↔Z, B↔Y)."""
    
    @staticmethod
    def transform(text: str) -> str:
        """Apply Atbash transformation (encrypt = decrypt)."""
        result = []
        for char in text:
            if char.isalpha():
                if char.isupper():
                    result.append(chr(ord('Z') - (ord(char) - ord('A'))))
                else:
                    result.append(chr(ord('z') - (ord(char) - ord('a'))))
            else:
                result.append(char)
        return ''.join(result)


# ============================================================
# ENCODING
# ============================================================

class Encoding:
    """Common encoding functions."""
    
    @staticmethod
    def base64_encode(text: str) -> str:
        """Encode text to Base64."""
        return base64.b64encode(text.encode('utf-8')).decode('utf-8')
    
    @staticmethod
    def base64_decode(encoded: str) -> str:
        """Decode Base64 to text."""
        return base64.b64decode(encoded).decode('utf-8')
    
    @staticmethod
    def hex_encode(text: str) -> str:
        """Encode text to hexadecimal."""
        return text.encode('utf-8').hex()
    
    @staticmethod
    def hex_decode(encoded: str) -> str:
        """Decode hexadecimal to text."""
        return bytes.fromhex(encoded).decode('utf-8')
    
    @staticmethod
    def binary_encode(text: str) -> str:
        """Encode text to binary."""
        return ' '.join(format(byte, '08b') for byte in text.encode('utf-8'))
    
    @staticmethod
    def binary_decode(encoded: str) -> str:
        """Decode binary to text."""
        bytes_list = [int(b, 2) for b in encoded.split()]
        return bytes(bytes_list).decode('utf-8')
    
    @staticmethod
    def url_encode(text: str) -> str:
        """URL encode text."""
        return urllib.parse.quote(text)
    
    @staticmethod
    def url_decode(encoded: str) -> str:
        """URL decode text."""
        return urllib.parse.unquote(encoded)
    
    @staticmethod
    def ascii85_encode(text: str) -> str:
        """Encode text to ASCII85/Base85."""
        return base64.a85encode(text.encode('utf-8')).decode('utf-8')
    
    @staticmethod
    def ascii85_decode(encoded: str) -> str:
        """Decode ASCII85/Base85 to text."""
        return base64.a85decode(encoded).decode('utf-8')


# ============================================================
# UTILITY FUNCTIONS
# ============================================================

def generate_random_key(length: int = 32) -> str:
    """Generate a random key of specified length."""
    import secrets
    import string
    alphabet = string.ascii_letters + string.digits
    return ''.join(secrets.choice(alphabet) for _ in range(length))


def generate_secure_password(length: int = 16) -> str:
    """Generate a secure random password."""
    import secrets
    import string
    alphabet = string.ascii_letters + string.digits + string.punctuation
    # Ensure at least one of each type
    password = [
        secrets.choice(string.ascii_lowercase),
        secrets.choice(string.ascii_uppercase),
        secrets.choice(string.digits),
        secrets.choice(string.punctuation)
    ]
    password += [secrets.choice(alphabet) for _ in range(length - 4)]
    import random
    random.shuffle(password)
    return ''.join(password)


# ============================================================
# MAIN DEMO
# ============================================================

def demo():
    """Demonstrate all cryptography functions."""
    print("=" * 60)
    print("CryptoUI Pro - Python Cryptography Toolkit Demo")
    print("=" * 60)
    
    message = "Hello, Quantum World!"
    key = "MySecretKey123456"
    
    # AES-256-GCM
    print("\n📦 AES-256-GCM Encryption")
    print("-" * 40)
    try:
        encrypted = AES256GCM.encrypt(message, key)
        print(f"Encrypted: {json.dumps(encrypted, indent=2)}")
        decrypted = AES256GCM.decrypt(encrypted, key)
        print(f"Decrypted: {decrypted}")
    except ImportError as e:
        print(f"⚠️ Library not installed: {e}")
    
    # ChaCha20-Poly1305
    print("\n⚡ ChaCha20-Poly1305 Encryption")
    print("-" * 40)
    try:
        encrypted = ChaCha20Poly1305.encrypt(message, key)
        print(f"Encrypted: {json.dumps(encrypted, indent=2)}")
        decrypted = ChaCha20Poly1305.decrypt(encrypted, key)
        print(f"Decrypted: {decrypted}")
    except ImportError as e:
        print(f"⚠️ Library not installed: {e}")
    
    # RSA-OAEP
    print("\n🔑 RSA-OAEP Encryption")
    print("-" * 40)
    try:
        public_key, private_key = RSA_OAEP.generate_keypair()
        print(f"Public key: {public_key[:50].decode()}...")
        encrypted = RSA_OAEP.encrypt(message, public_key)
        print(f"Encrypted: {encrypted['ciphertext'][:50]}...")
        decrypted = RSA_OAEP.decrypt(encrypted, private_key)
        print(f"Decrypted: {decrypted}")
    except ImportError as e:
        print(f"⚠️ Library not installed: {e}")
    
    # Hashing
    print("\n#️⃣ Hashing Functions")
    print("-" * 40)
    print(f"SHA-256: {Hashing.sha256(message)}")
    print(f"SHA-512: {Hashing.sha512(message)[:64]}...")
    print(f"SHA3-256: {Hashing.sha3_256(message)}")
    print(f"BLAKE2b: {Hashing.blake2b(message)[:64]}...")
    
    # HMAC
    print("\n🔏 HMAC-SHA256")
    print("-" * 40)
    hmac_result = HMAC_SHA256.generate(message, key)
    print(f"HMAC: {hmac_result}")
    print(f"Verified: {HMAC_SHA256.verify(message, key, hmac_result)}")
    
    # PBKDF2
    print("\n🔧 PBKDF2 Key Derivation")
    print("-" * 40)
    derived_key, salt = PBKDF2.derive("password123", iterations=10000)
    print(f"Derived key: {derived_key}")
    print(f"Salt: {salt}")
    
    # Classical Ciphers
    print("\n📜 Classical Ciphers")
    print("-" * 40)
    print(f"Caesar (shift 3): {CaesarCipher.encrypt(message, 3)}")
    print(f"Vigenère (key='KEY'): {VigenereCipher.encrypt(message, 'KEY')}")
    print(f"ROT13: {ROT13.transform(message)}")
    print(f"Atbash: {AtbashCipher.transform(message)}")
    
    # Encoding
    print("\n📦 Encoding")
    print("-" * 40)
    print(f"Base64: {Encoding.base64_encode(message)}")
    print(f"Hex: {Encoding.hex_encode(message)}")
    print(f"Binary: {Encoding.binary_encode(message[:5])}...")
    print(f"URL: {Encoding.url_encode(message)}")
    
    # Post-Quantum (if available)
    print("\n⚛️ Post-Quantum Cryptography")
    print("-" * 40)
    try:
        print("Testing Kyber-768...")
        public_key, private_key = Kyber768.generate_keypair()
        print(f"Public key size: {len(public_key)} bytes")
        shared_secret, ciphertext = Kyber768.encapsulate(public_key)
        print(f"Shared secret size: {len(shared_secret)} bytes")
        recovered = Kyber768.decapsulate(ciphertext, private_key)
        print(f"Keys match: {shared_secret == recovered}")
    except ImportError as e:
        print(f"⚠️ PQC library not installed: {e}")
    
    try:
        print("\nTesting Dilithium-3...")
        public_key, private_key = Dilithium3.generate_keypair()
        print(f"Public key size: {len(public_key)} bytes")
        signature = Dilithium3.sign(message.encode(), private_key)
        print(f"Signature size: {len(signature)} bytes")
        verified = Dilithium3.verify(message.encode(), signature, public_key)
        print(f"Signature valid: {verified}")
    except ImportError as e:
        print(f"⚠️ PQC library not installed: {e}")
    
    print("\n" + "=" * 60)
    print("Demo complete!")
    print("=" * 60)


if __name__ == "__main__":
    demo()
